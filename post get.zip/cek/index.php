<?php
$nama = $_POST['nama'];
$email = $_POST['email'];
?>

<h2>Data yang Dikirim:</h2>
<p>Nama: <?php echo $nama; ?></p>
<p>Email: <?php echo $email; ?></p>
